-- Shared functional move-description provider.
-- Gen1Recomp's extracted ROM move rows contain effect metadata but no flavor
-- descriptions. This service uses explicit engine/mod fields first, curated
-- Gen 1 descriptions for important exceptions second, then deterministic
-- metadata-derived text so every move has a usable, non-fictional fallback.
return function(deps)
  local mod=assert(deps.mod);local Service={}
  local CURATED={
    TACKLE="A full-body charge that damages the target.",
    SAND_ATTACK="Throws sand at the target to lower its accuracy.",
    HYPER_BEAM="A powerful beam attack. The user normally recharges next turn.",
    QUICK_ATTACK="A fast attack that strikes before most other moves.",
    WRAP="Wraps the target and prevents it from attacking while the effect lasts.",
    DRAGON_RAGE="Always deals exactly 40 HP of damage.",
    THUNDER_WAVE="Paralyzes the target without dealing direct damage.",
    THUNDERBOLT="An electric attack that may paralyze the target.",
    AGILITY="Sharply raises the user's Speed.",
    REST="The user sleeps to fully restore HP and clear status conditions.",
    SLAM="Slams the target with a long body or tail.",
    TOXIC="Badly poisons the target; damage increases each turn.",
    GROWL="Lowers the target's Attack.",
    LEER="Lowers the target's Defense.",
    TAIL_WHIP="Lowers the target's Defense.",
    STRING_SHOT="Lowers the target's Speed.",
    HARDEN="Raises the user's Defense.",
    DEFENSE_CURL="Raises the user's Defense.",
    BARRIER="Sharply raises the user's Defense.",
    AMNESIA="Sharply raises the user's Special.",
    RECOVER="Restores up to half of the user's maximum HP.",
    SOFT_BOILED="Restores up to half of the user's maximum HP.",
    TRANSFORM="Copies the target's form, stats and moves for the battle.",
    SPLASH="Has no effect.",
    METRONOME="Uses another move chosen at random.",
    MIMIC="Copies one of the target's moves for the battle.",
    MIRROR_MOVE="Repeats the last move used by the target.",
    HAZE="Resets battle stat changes.",
    MIST="Prevents the user's stats from being lowered.",
    LIGHT_SCREEN="Reduces damage from special attacks.",
    REFLECT="Reduces damage from physical attacks.",
    SUBSTITUTE="Uses HP to create a substitute that absorbs attacks.",
    FOCUS_ENERGY="Raises the user's critical-hit rate.",
    BIDE="Stores damage for several turns, then returns double the damage received.",
    COUNTER="Returns double the damage from a qualifying physical attack.",
    SEISMIC_TOSS="Deals damage equal to the user's level.",
    NIGHT_SHADE="Deals damage equal to the user's level.",
    SONIC_BOOM="Always deals exactly 20 HP of damage.",
    SUPER_FANG="Cuts the target's current HP in half.",
    PSYWAVE="Deals a variable amount of damage based on the user's level.",
    FISSURE="A one-hit knockout attack with low accuracy.",
    GUILLOTINE="A one-hit knockout attack with low accuracy.",
    HORN_DRILL="A one-hit knockout attack with low accuracy.",
    SELFDESTRUCT="Causes the user to faint and deals very high damage.",
    EXPLOSION="Causes the user to faint and deals extremely high damage.",
    PAY_DAY="Scatters coins that are collected after the battle.",
    TELEPORT="Escapes from a wild battle or returns to a previous location outside battle.",
    ROAR="Ends a wild battle by forcing the target away.",
    WHIRLWIND="Ends a wild battle by forcing the target away.",
  }
  local EFFECT={
    NO_ADDITIONAL_EFFECT="Deals damage.",
    POISON_SIDE_EFFECT1="Deals damage and may poison the target.",POISON_SIDE_EFFECT2="Deals damage and may poison the target.",
    BURN_SIDE_EFFECT1="Deals damage and may burn the target.",BURN_SIDE_EFFECT2="Deals damage and may burn the target.",
    FREEZE_SIDE_EFFECT="Deals damage and may freeze the target.",PARALYZE_SIDE_EFFECT1="Deals damage and may paralyze the target.",PARALYZE_SIDE_EFFECT2="Deals damage and may paralyze the target.",
    FLINCH_SIDE_EFFECT1="Deals damage and may make the target flinch.",FLINCH_SIDE_EFFECT2="Deals damage and may make the target flinch.",
    CONFUSION_SIDE_EFFECT="Deals damage and may confuse the target.",
    ATTACK_DOWN1_SIDE_EFFECT="Deals damage and may lower the target's Attack.",DEFENSE_DOWN1_SIDE_EFFECT="Deals damage and may lower the target's Defense.",SPEED_DOWN1_SIDE_EFFECT="Deals damage and may lower the target's Speed.",SPECIAL_DOWN1_SIDE_EFFECT="Deals damage and may lower the target's Special.",
    ATTACK_DOWN1_EFFECT="Lowers the target's Attack.",DEFENSE_DOWN1_EFFECT="Lowers the target's Defense.",SPEED_DOWN1_EFFECT="Lowers the target's Speed.",SPECIAL_DOWN1_EFFECT="Lowers the target's Special.",ACCURACY_DOWN1_EFFECT="Lowers the target's accuracy.",EVASION_DOWN1_EFFECT="Lowers the target's evasion.",
    ATTACK_UP1_EFFECT="Raises the user's Attack.",DEFENSE_UP1_EFFECT="Raises the user's Defense.",SPEED_UP1_EFFECT="Raises the user's Speed.",SPECIAL_UP1_EFFECT="Raises the user's Special.",EVASION_UP1_EFFECT="Raises the user's evasion.",
    ATTACK_UP2_EFFECT="Sharply raises the user's Attack.",DEFENSE_UP2_EFFECT="Sharply raises the user's Defense.",SPEED_UP2_EFFECT="Sharply raises the user's Speed.",SPECIAL_UP2_EFFECT="Sharply raises the user's Special.",
    SLEEP_EFFECT="Puts the target to sleep.",POISON_EFFECT="Poisons the target.",PARALYZE_EFFECT="Paralyzes the target.",CONFUSION_EFFECT="Confuses the target.",
    DRAIN_HP_EFFECT="Deals damage and restores HP to the user.",DREAM_EATER_EFFECT="Damages a sleeping target and restores HP to the user.",
    MULTI_HIT_EFFECT="Hits the target multiple times.",TWO_TO_FIVE_ATTACKS_EFFECT="Hits the target two to five times.",TWO_ATTACKS_EFFECT="Hits the target twice.",
    RECOIL_EFFECT="Deals damage and also damages the user.",TRAPPING_EFFECT="Traps the target for several turns.",
  }
  local function normalize(value) return tostring(value or ""):upper():gsub("[^A-Z0-9]+","_"):gsub("^_+",""):gsub("_+$","") end
  function Service.describe(def,id)
    def=type(def)=="table" and def or {};id=normalize(id or def.id or def.name)
    for _,key in ipairs({"description","desc","summary","text"}) do local v=def[key];if type(v)=="string" and v~="" then return v,"move_def."..key end end
    if CURATED[id] then return CURATED[id],"krs.curated" end
    local effect=normalize(def.effect);if EFFECT[effect] then return EFFECT[effect],"rom.effect."..effect end
    local power=tonumber(def.power) or 0;local typeName=tostring(def.type or ""):gsub("_"," "):lower()
    if power>0 then return typeName~="" and ("Deals damage with a "..typeName.."-type attack.") or "Deals damage.","rom.metadata" end
    return "Applies its battle effect without dealing direct damage.","rom.metadata"
  end
  function Service.catalogStatus() return {curated=true,metadataFallback=true,engineFlavorText=false} end
  mod.log:info("Move description service active: engine fields, curated exceptions and ROM metadata fallback")
  return Service
end
